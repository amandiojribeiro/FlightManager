﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Windows.Forms;

namespace RestApiTest
{
    public partial class Form1 : Form
    {
        private string urlParameters;

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

                //System.Text.StringBuilder strToxml = new System.Text.StringBuilder();
                //strToxml.Append("{\"Properties\": [");
                //var strArrayTemp = textBox2.Text.Split('&');
                //for (int i = 0; i < strArrayTemp.Count(); i++)
                //{
                //    var strSplitedTemp = strArrayTemp[i];
                //    switch (i)
                //    {
                //        case 0:
                //        {
                //            strToxml.Append("{\"Name\": \"" + strSplitedTemp[0] + "\",\"Value\": \"" + strSplitedTemp[1] + "\"}");
                //            break;
                //        } 
                //        default:
                //        {
                //            strToxml.Append(",{\"Name\": \"" + strSplitedTemp[0] + "\",\"Value\": \"" + strSplitedTemp[1] + "\"}");
                //            break;
                //        }
                //    }
                //}

                //strToxml.Append("]}");

                //var cenas = strToxml.ToString();

                // First create a proxy object

               


            HttpClient client = new HttpClient();

                client.BaseAddress = new Uri(textBox1.Text);

                // Add an Accept header for JSON format.
                client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));

                //var jsonString = JsonConvert.SerializeObject(textBox2.Text);

                //var parameters = new Dictionary<string, string> { { "parameter", textBox2.Text } };

                var content = new StringContent(content: textBox2.Text, encoding: Encoding.UTF8, mediaType: "application/json");

                //var content = new FormUrlEncodedContent(parameters);
                var response = client.PostAsJsonAsync(textBox1.Text, content).Result;
                
                var responseString = response.Content.ReadAsStringAsync().Result;

               

                textBox3.Text += responseString + Environment.NewLine;

            }
            catch (Exception ex)
            {

                textBox3.Text = ex.Message;
            }
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();
            var response = client.GetAsync(textBox1.Text).Result;
            var responseString = response.Content.ReadAsStringAsync().Result;

            var jsonTextData = responseString;
            var messages = Newtonsoft.Json.JsonConvert.DeserializeObject<MUFG.Mifid2Service.ApiModels.Model.Message[]>(jsonTextData).ToList();
            var lstResponse = new List<string>();
            int nSize = 99;

            for (int i = 0; i < messages.Count; i += nSize)
            {
                lstResponse.Add(Newtonsoft.Json.JsonConvert.SerializeObject(messages.GetRange(i, Math.Min(nSize, messages.Count - i))));
            }

            foreach(var x in lstResponse)
            {
                textBox3.Text += x + Environment.NewLine + "--------------------------------------------" + Environment.NewLine;
            }
        }
    }

    public class ResponseFileDto
    {
        public string Base64FileContent { get; set; }

        public string FileName { get; set; }
    }
}
