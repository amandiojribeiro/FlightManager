﻿namespace MUFG.Reporting.Service.Domain.Core.GatewayInterfaces
{
    using MUFG.Reporting.Service.Domain.Model;
    using System.IO;
    using System.Threading.Tasks;

    public interface IReportGateway
    {
        string FileName { get; }

        Task<byte[]> GetReport(Parameter param);
    }
}
