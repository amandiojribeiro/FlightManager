﻿namespace MUFG.Reporting.Service.Dto
{
    public class PropertyDto
    {
        public string Name { get; set; }

        public string Value { get; set; }
    }
}
