﻿namespace MUFG.Reporting.Service.Dto
{
    using System.Collections.Generic;

    public class ParameterDto
    {
        public string BaseAddress { get; set; }

        public string Resource { get; set; }

        public string Verb { get; set; }

        public string Format { get; set; }

        public List<PropertyDto> Properties { get; set; }
    }
}
