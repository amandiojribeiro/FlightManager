﻿using System;
namespace MUFG.Reporting.Service.Dto
{
    public class ResponseFileDto
    {
        public string Base64FileContent { get; set; }

        public string FileName { get; set; }
    }
}
