﻿namespace MUFG.Reporting.Service.Data.Gateway
{
    using Data.Gateway.SSRSWebService;
    using Domain.Core.GatewayInterfaces;
    using Domain.Model;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class SqlReportGateway : IReportGateway
    {
        private ReportExecutionServiceSoapClient _reportExecutionServiceSoapClient;

        private string fileName;

        public string FileName { get { return this.fileName; } }

        public SqlReportGateway()
        {
            this._reportExecutionServiceSoapClient = new ReportExecutionServiceSoapClient();
            this._reportExecutionServiceSoapClient.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;
        }

        public async Task<byte[]> GetReport(Parameter param)
        {
            this.fileName = param.Properties.Where(x => x.Name.Contains("ReportName")).FirstOrDefault().Value;

            string historyID = null;
           
            TrustedUserHeader trustedUserHeader = new TrustedUserHeader();
            ExecutionHeader execHeader = new ExecutionHeader();

            LoadReportResponse taskLoadReport = await this._reportExecutionServiceSoapClient.LoadReportAsync(trustedUserHeader,param.Properties.Where(x=>x.Name.Contains("ReportPath")).FirstOrDefault().Value , historyID);

            if (taskLoadReport.executionInfo != null)
            {
                execHeader.ExecutionID = taskLoadReport.executionInfo.ExecutionID;
            }

            var parameters = GetParameters(param);

            if (parameters != null)
            {
                await this._reportExecutionServiceSoapClient.SetExecutionParametersAsync(execHeader, trustedUserHeader, parameters, "en-US");
            }

            string deviceInfo = null;
            string format = param.Properties.Where(x=>x.Name.Contains("ReportFormat")).FirstOrDefault().Value;

            RenderRequest renderReq = new RenderRequest(execHeader, trustedUserHeader, format, deviceInfo);
            RenderResponse taskRender = await this._reportExecutionServiceSoapClient.RenderAsync(renderReq);
            
            if (taskRender.Result != null)
            {
                return taskRender.Result;
            }

            return null;
        }

        private ParameterValue[] GetParameters(Parameter param)
        {
            var listOfParamsToRemove = new List<string>() { "ReportPath", "ReportName", "ReportFormat" };
            var props = param.Properties.Where(x => !listOfParamsToRemove.Contains(x.Name));

            if (props.Count() > 0)
            {
                ParameterValue[] paramsToSSRS = new ParameterValue[props.Count()];
                int count = 0;
                foreach (Property prop in props)
                {
                    ParameterValue reportParameter = new ParameterValue(){ Name = prop.Name, Value = prop.Value };
                    paramsToSSRS[count] = reportParameter;
                    count++;
                }

                return paramsToSSRS;
            }

            return null;
        }
    }
}
