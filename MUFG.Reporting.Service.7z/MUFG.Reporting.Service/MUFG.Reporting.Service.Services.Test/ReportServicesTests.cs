﻿namespace Application.Services.Test
{
    using Application.Dto;
    using Application.Services.ReportServices;
    using Domain.Core.GatewayInterfaces;
    using Infrastructure.CrossCutting.Adapters;
    using Infrastructure.CrossCutting.Adapters.Automapper;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Reflection;

    [TestClass()]
    [ExcludeFromCodeCoverage]
    public class ReportServicesTests
    {
        [TestInitialize]
        public void Setup()
        {
            Assembly.Load("Application.Services");
            TypeAdapterFactory.SetCurrent(new AutomapperTypeAdapterFactory());
        }

        [TestMethod()]
        [ExpectedException(typeof(AggregateException),)]
        public void Get_GetStreamReport_Null_ParameterDto_is_passed()
        {
            var sqlReportGatewayMock = new Mock<IReportGateway>();

            var reportServices = new ReportServices(sqlReportGatewayMock.Object);
            var result = reportServices.GetStreamReport(null).Result;
        }

        [TestMethod()]
        public void Get_GetStreamReport_Empty_ParameterDto_is_passed()
        {
            var sqlReportGatewayMock = new Mock<IReportGateway>();

            var reportServices = new ReportServices(sqlReportGatewayMock.Object);
            var result = reportServices.GetStreamReport(new ParameterDto()).Result;
        }
    }
}
