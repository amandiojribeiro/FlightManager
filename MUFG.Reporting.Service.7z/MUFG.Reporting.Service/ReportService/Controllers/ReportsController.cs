﻿namespace ReportService.Controllers
{
    using MUFG.Reporting.Service.Dto;
	using MUFG.Reporting.Service.Infrastructure.Crosscuting.Logging;
	using MUFG.Reporting.Service.Services.ReportServices;
    using Newtonsoft.Json;
    using System.IO;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using System.Web.Http.Description;

    /// <summary>
    /// Managing report generation
    /// </summary>
    [RoutePrefix("reports")]
    public class ReportsController : ApiController
    {
        private readonly IReportServices reportServices;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="reportServices"></param>
        public ReportsController(IReportServices reportServices)
        {
            this.reportServices = reportServices;
        }

        /// <summary> 
        /// Generate a report and return a stream to the client
        /// </summary> 
        /// <param name="parameter">value representing the parameter object with pertinent information to genarate the report</param> 
        /// <response code="200">report</response> 
        /// <response code="404">No report found</response> 
        /// <response code="400">Bad Request</response> 
        /// <response code="401">Unauthorized Request</response> 
        /// <response code="500">Internal Server Error</response> 
        [HttpPost, Route("getReport"), ResponseType(typeof(ResponseFileDto))]
        public async Task<HttpResponseMessage> GetReport(ParameterDto parameter)
        {
			try
			{
				var result = await this.reportServices.GetStreamReport(parameter);
               
				if (result != null) 
				{ 
					return Request.CreateResponse(System.Net.HttpStatusCode.OK, result); 
				}

				return Request.CreateResponse(System.Net.HttpStatusCode.NotFound); 
			}
			catch (System.Exception ex)
			{
				//var fileName = @"D:\inetpub\Logs\DEV\ReportService\report-service-debug.txt";

				System.Text.StringBuilder sb = new System.Text.StringBuilder();
				sb.AppendLine($"Exception Message: {ex.Message}");
				sb.AppendLine($"Stack Trace: {ex.StackTrace}");

				System.Exception innerEx = ex.InnerException;

				while (innerEx != null)
				{
					sb.AppendLine($"Exception Message: {innerEx.Message}");
					sb.AppendLine($"Stack Trace: {innerEx.StackTrace}");
				}

				await Log.LogException(ex, parameter);

				//System.IO.File.AppendAllText(fileName, sb.ToString());

				return Request.CreateErrorResponse(System.Net.HttpStatusCode.InternalServerError, sb.ToString());
				//throw;
			}

        }
    }
}
