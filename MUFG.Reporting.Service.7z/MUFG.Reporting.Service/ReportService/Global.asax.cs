﻿namespace ReportService
{
    using MUFG.Reporting.Service.Infrastructure.CrossCutting.Adapters;
    using MUFG.Reporting.Service.Infrastructure.CrossCutting.Adapters.Automapper;
    using System.Web.Http;

    /// <summary>
    /// 
    /// </summary>
    public class WebApiApplication : System.Web.HttpApplication
    {
        /// <summary>
        /// 
        /// </summary>
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
            TypeAdapterFactory.SetCurrent(new AutomapperTypeAdapterFactory());
        }
    }
}
