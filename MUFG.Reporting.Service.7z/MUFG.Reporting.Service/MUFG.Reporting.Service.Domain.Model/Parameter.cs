﻿namespace MUFG.Reporting.Service.Domain.Model
{
    using System.Collections.Generic;

    public class Parameter
    {
        public List<Property> Properties { get; set; }

    }
}
