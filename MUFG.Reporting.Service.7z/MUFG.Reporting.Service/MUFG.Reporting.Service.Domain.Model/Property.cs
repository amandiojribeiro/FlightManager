﻿namespace MUFG.Reporting.Service.Domain.Model
{
    public class Property
    {
        public string Name { get; set; }

        public string Value { get; set; }
    }
}
