﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using MUFG.Reporting.Service.Dto;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;

namespace MUFG.Reporting.Service.Infrastructure.Crosscuting.Logging
{
	public static class Log
	{

		private static string _endPointUrl = string.Empty;

		static Log()
		{
			var appSettings = ConfigurationManager.AppSettings;
			if (appSettings.Get("LogServiceEndPoint") != null)
			{
				_endPointUrl = appSettings.Get("LogServiceEndPoint");
			}
		}


		public static async Task LogException(Exception ex, ParameterDto parameter = null)
		{
			await SendToLog("Error", ex.Message, ex.StackTrace, parameter);
		}
		public static async Task LogError(string message, ParameterDto parameter = null)
		{
			await SendToLog("Error", message, string.Empty, parameter);
		}


		private static async Task SendToLog(string logLevel, string message, string stackTrace = "", ParameterDto parameter = null)
		{
			try
			{

				dynamic log = new Object();

				StringBuilder prmJson = new StringBuilder();

				if (parameter != null)
				{

					prmJson.AppendLine("[");
					prmJson.AppendLine("	{ " + $"BaseAddress: {parameter.BaseAddress}" + " }");
					prmJson.AppendLine("	{ " + $"Resource: {parameter.Resource}" + " }");
					prmJson.AppendLine("	{ " + $"Verb: {parameter.Verb}" + " }");
					prmJson.AppendLine("	{ " + $"Format: {parameter.Format}" + " }");

					if(parameter.Properties != null)
					{
						prmJson.AppendLine("	{ Properties: [");
						foreach(var prop in parameter.Properties)
						{
							prmJson.AppendLine("		{ " + $"{prop.Name ?? "null"}: {prop.Value ?? "null"}" + " }");
						}
						prmJson.AppendLine("		]");
						prmJson.AppendLine("	}");
					}

					prmJson.AppendLine("]");
				}

				log.businessKey = "Reporting-Service-API";
				log.entityClassMethod = "Reporting Logger";
				log.entityName = Guid.NewGuid();
				log.entityParams = prmJson.ToString();
				log.callStack = stackTrace;
				log.entityUri = "";
				log.httpHeader = "";
				log.httpMethod = "";
				log.logLevel = logLevel;
				log.logMessage = message;
				log.userId = "";


				string payload = JsonConvert.SerializeObject(prmJson);

				using (HttpClient client = new HttpClient())
				{
					client.BaseAddress = new Uri(_endPointUrl);
					var contentType = new MediaTypeWithQualityHeaderValue("application/json");
					client.DefaultRequestHeaders.Accept.Add(contentType);

					var httpContent = new StringContent(payload, Encoding.UTF8, "application/json");


					var response = await client.PostAsync("api/v1/monitor/log", httpContent);
				}
			}
			catch (Exception ex)
			{
				// ok couldn't log but that shouldn't prevent us from doing our work	

				try
				{
					var fileName = @"D:\inetpub\Logs\DEV\ReportService\report-service-debug.txt";

					System.Text.StringBuilder sb = new System.Text.StringBuilder();
					sb.AppendLine($"Exception Message: {ex.Message}");
					sb.AppendLine($"Stack Trace: {ex.StackTrace}");

					System.Exception innerEx = ex.InnerException;

					while (innerEx != null)
					{
						sb.AppendLine($"Exception Message: {innerEx.Message}");
						sb.AppendLine($"Stack Trace: {innerEx.StackTrace}");
					}

					System.IO.File.AppendAllText(fileName, sb.ToString());
				}
				catch
				{
				}
			}

		}



	}
}
