﻿namespace MUFG.Reporting.Service.Services.TypeAdapters
{
    using AutoMapper;
    using Domain.Model;
    using MUFG.Reporting.Service.Dto;

    public class DtoAdapterProfile : Profile
    {
        protected override void Configure()
        {
            Mapper.CreateMap<Parameter, ParameterDto>()
            .ForMember(dest => dest.Properties, opt => opt.MapFrom(e => e.Properties))
            .ReverseMap();

            Mapper.CreateMap<Property, PropertyDto>()
            .ForMember(dest => dest.Value, opt => opt.MapFrom(e => e.Value))
            .ForMember(dest => dest.Name, opt => opt.MapFrom(e => e.Name))
            .ReverseMap();
        }
    }
}
