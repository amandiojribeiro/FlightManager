﻿namespace MUFG.Reporting.Service.Services.ReportServices
{
    using System.IO;
    using System.Threading.Tasks;
    using MUFG.Reporting.Service.Dto;
    using Domain.Core.GatewayInterfaces;
    using Infrastructure.CrossCutting.Adapters;
    using Domain.Model;
    using System.Linq;
    using System;

    public class ReportServices : IReportServices
    {
        private readonly IReportGateway reportGateway;

        public ReportServices(IReportGateway reportGateway)
        {
            this.reportGateway = reportGateway;
        }

        public async Task<ResponseFileDto> GetStreamReport(ParameterDto parameterDto)
        {
            var reportResult = await this.reportGateway.GetReport(TypeAdapterHelper.Adapt<Parameter>(parameterDto));
            var result = new ResponseFileDto() { Base64FileContent = Convert.ToBase64String(reportResult), FileName = this.reportGateway.FileName };
            return result;
        }
         
        public Task SaveReport(Stream report)
        {
            throw new System.NotImplementedException();
        }
    }
}
