﻿namespace MUFG.Reporting.Service.Services.ReportServices
{
    using MUFG.Reporting.Service.Dto;
    using System.IO;
    using System.Threading.Tasks;

    public interface IReportServices
    {
        Task<ResponseFileDto> GetStreamReport(ParameterDto parameterDto);

        Task SaveReport(Stream report);
    }
}
