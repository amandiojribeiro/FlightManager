﻿namespace MUFG.RRH.Service.Dto
{
    public class FakeTestDto
    {
        public string cenas { get; set; }
    }
}
