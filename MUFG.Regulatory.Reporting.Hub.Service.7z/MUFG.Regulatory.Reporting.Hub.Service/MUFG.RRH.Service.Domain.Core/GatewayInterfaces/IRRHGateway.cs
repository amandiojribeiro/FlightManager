﻿namespace MUFG.RRH.Service.Domain.Core.GatewayInterfaces
{
    using System.Threading.Tasks;

    public interface IRRHGateway
    {
        Task<string> SendMessage(string xmlDoc);
    }
}
