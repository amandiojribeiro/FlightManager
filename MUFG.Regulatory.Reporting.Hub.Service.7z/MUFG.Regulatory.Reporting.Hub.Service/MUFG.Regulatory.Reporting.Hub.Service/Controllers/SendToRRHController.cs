﻿namespace MUFG.Regulatory.Reporting.Hub.Service.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using MUFG.RRH.Service.Services.IRRHServices;
    using System.Threading.Tasks;

    [Route("api/[controller]")]
    public class SendToRRHController : Controller
    {
        private readonly IRRHServices rRHServices;

        public SendToRRHController(IRRHServices rRHServices)
        {
            this.rRHServices = rRHServices;
        }

        // POST api/sendtorrh
        [HttpPost]
        public async Task<IActionResult> Post([FromBody]string XmlRequest)
        {
            return Ok(await this.rRHServices.SendMessage(XmlRequest));
        }
    }
}
