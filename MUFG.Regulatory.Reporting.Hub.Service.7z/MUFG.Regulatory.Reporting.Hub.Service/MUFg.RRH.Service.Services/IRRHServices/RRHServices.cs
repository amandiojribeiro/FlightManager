﻿
namespace MUFG.RRH.Service.Services.IRRHServices
{
    using MUFG.RRH.Service.Domain.Core.GatewayInterfaces;
    using MUFG.RRH.Service.Domain.Model;
    using MUFG.RRH.Service.Dto;
    using MUFG.RRH.Service.Infrastructure.Crosscuting;
    using System.Threading.Tasks;

    public class RRHServices : IRRHServices
    {
        private readonly IRRHGateway rRHGateway;

        public RRHServices(IRRHGateway rRHGateway)
        {
            this.rRHGateway = rRHGateway;
        }

        public async Task<string> SendMessage(string xmlDoc)
        {
            return await this.rRHGateway.SendMessage(xmlDoc);
        }
    }
}
