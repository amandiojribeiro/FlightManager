﻿namespace MUFG.RRH.Service.Services.IRRHServices
{
    using System.Threading.Tasks;

    public interface IRRHServices
    {
        Task<string> SendMessage(string xmlDoc);
    }
}
