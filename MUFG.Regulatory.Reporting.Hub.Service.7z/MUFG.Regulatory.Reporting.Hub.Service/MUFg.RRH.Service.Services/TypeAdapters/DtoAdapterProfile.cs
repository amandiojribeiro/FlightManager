﻿namespace MUFG.RRH.Service.Services.TypeAdapters
{
    using AutoMapper;
    using MUFG.RRH.Service.Domain.Model;
    using MUFG.RRH.Service.Dto;

    public class DtoAdapterProfile : Profile
    {
        public override string ProfileName
        {
            get { return "DtoAdapterProfile"; }
        }

        public DtoAdapterProfile()
        {
            CreateMap<FakeTestDto, FakeTest>()
            .ForMember(dest => dest.cenas, opt => opt.MapFrom(e => e.cenas))
            .ReverseMap();
        }

    }
}
