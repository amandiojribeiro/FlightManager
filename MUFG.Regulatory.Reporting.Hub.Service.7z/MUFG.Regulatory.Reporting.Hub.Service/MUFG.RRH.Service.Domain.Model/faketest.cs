﻿namespace MUFG.RRH.Service.Domain.Model
{
    public class FakeTest
    {
        public string cenas { get; set; }
    }
}
