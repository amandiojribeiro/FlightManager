﻿namespace MUFG.RRH.Service.Data.Gateway
{
    using System.Threading.Tasks;
    using MUFG.RRH.Service.Domain.Core.GatewayInterfaces;

    public class QuickFixNRRHGateway : IRRHGateway
    {
        public Task<string> SendMessage(string xmlDoc)
        {
            return Task.FromResult<string>("This is a test response");
        }
    }
}
